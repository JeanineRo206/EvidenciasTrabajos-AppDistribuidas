package com.example.flutter_client_dart_rest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

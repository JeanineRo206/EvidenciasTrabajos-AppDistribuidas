import 'package:flutter_client_dart_rest/domain/Entities/product.dart';

abstract class IGetProductRepository {
  Future<List<Product>> getAll();
}

import 'package:flutter_client_dart_rest/domain/Interfaces/i_get_product_repository.dart';
import 'package:flutter_client_dart_rest/domain/Entities/product.dart';

class GetProductList {
  final IGetProductRepository _repository;

  GetProductList(this._repository);

  Future<List<Product>> execute() {
    return _repository.getAll();
  }
}

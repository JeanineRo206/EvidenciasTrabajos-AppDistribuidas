class Product {
  final String id;
  final String name;
  final String? description;
  final int price;
  final int stock;
  final bool status;

  Product({
    required this.id,
    required this.name,
    this.description,
    required this.price,
    required this.stock,
    required this.status,
  });
}

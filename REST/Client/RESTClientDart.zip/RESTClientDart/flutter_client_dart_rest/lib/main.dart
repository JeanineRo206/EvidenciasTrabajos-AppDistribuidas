import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Cliente de API REST'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Product> products = [];
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _stockController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _newStockController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _getProducts();
  }

  Future<void> _getProducts() async {
    final response = await http.get(
        Uri.parse(
          'https://azf-products-jjj.azurewebsites.net/products',
        ),
        headers: <String, String>{'api-key': 'ApiKeyTestJJJAdminsIlimited'});

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      setState(() {
        products = data.map((item) => Product.fromJson(item)).toList();
      });
    } else {
      throw Exception('Failed to load products');
    }
  }

  Future<void> _addProduct() async {
    final newProduct = Product(
      name: _nameController.text,
      description: _descriptionController.text,
      stock: int.parse(_stockController.text),
      price: double.parse(_priceController.text),
      status: true,
    );

    final response = await http.post(
      Uri.parse('https://azf-products-jjj.azurewebsites.net/products'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'api-key': 'ApiKeyTestJJJAdminsIlimited'
      },
      body: jsonEncode(newProduct.toJson()),
    );

    if (response.statusCode == 200) {
      _nameController.clear();
      _descriptionController.clear();
      _stockController.clear();
      _priceController.clear();
      _getProducts();
    } else {
      throw Exception('Failed to add product');
    }
  }

  Future<void> _updateStock() async {
    final productIdToUpdate = _idController.text;
    final newStock = int.parse(_newStockController.text);

    final response = await http.patch(
      Uri.parse(
          'https://azf-products-jjj.azurewebsites.net/products/$productIdToUpdate'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'api-key': 'ApiKeyTestJJJAdminsIlimited'
      },
      body: jsonEncode(<String, dynamic>{'stock': newStock}),
    );

    if (response.statusCode == 200) {
      _idController.clear();
      _newStockController.clear();
      _getProducts();
    } else {
      throw Exception('Failed to update stock');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            const Text('Flutter App'),
            SizedBox(height: 20.0),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            TextField(
              controller: _stockController,
              decoration: InputDecoration(labelText: 'Stock'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              onPressed: () {
                _addProduct();
              },
              child: const Text('Add Product'),
            ),
            SizedBox(height: 40.0),
            TextField(
              controller: _idController,
              decoration: InputDecoration(labelText: 'Product ID to Update'),
            ),
            TextField(
              controller: _newStockController,
              decoration: InputDecoration(labelText: 'New Stock'),
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              onPressed: () {
                _updateStock();
              },
              child: const Text('Update Stock'),
            ),
            SizedBox(height: 40.0),
            Container(
              height: 300.0,
              child: ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemCount: products.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(products[index].name),
                    subtitle: Text(products[index].description),
                    trailing: Text('Stock: ${products[index].stock}'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Product {
  final int? id;
  final String name;
  final String description;
  final int stock;
  final double price;
  final bool? status;

  Product({
    this.id,
    required this.name,
    required this.description,
    required this.stock,
    required this.price,
    this.status,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'],
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      stock: json['stock'] ?? 0,
      price: double.parse(json['price']) ?? 0.0,
      status: json['status'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'stock': stock,
      'price': price,
    };
  }
}
